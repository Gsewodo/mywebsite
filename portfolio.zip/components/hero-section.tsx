export function HeroSection() {
  return (
    <section className="py-16 px-4">
      <div className="max-w-4xl mx-auto text-center">
        <div className="mb-8">
          <h2 className="text-4xl font-bold text-foreground mb-4">Développeur & Expert Cybersécurité</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Passionné par le développement web moderne, les réseaux et la cybersécurité. Je crée des solutions robustes
            et sécurisées en utilisant les dernières technologies. Spécialisé en React, Node.js, et sécurité des
            applications web.
          </p>
        </div>
      </div>
    </section>
  )
}
