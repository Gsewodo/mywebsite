import { PortfolioHeader } from "@/components/portfolio-header"
import { PortfolioFooter } from "@/components/portfolio-footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MapPin, Mail, Phone, Globe } from "lucide-react"

export default function CVPage() {
  return (
    <div className="min-h-screen bg-background">
      <PortfolioHeader />

      <main className="py-8 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-foreground mb-2">Curriculum Vitae</h1>
            <p className="text-muted-foreground">Développeur Full-Stack & Expert Cybersécurité</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="space-y-6">
              <Card className="bg-white border border-gray-200">
                <CardHeader>
                  <CardTitle className="text-lg">Contact</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-2 text-sm">
                    <Mail className="h-4 w-4 text-primary" />
                    votre.email@example.com
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Phone className="h-4 w-4 text-primary" />
                    +33 6 12 34 56 78
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="h-4 w-4 text-primary" />
                    Paris, France
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Globe className="h-4 w-4 text-primary" />
                    votre-portfolio.com
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white border border-gray-200">
                <CardHeader>
                  <CardTitle className="text-lg">Compétences</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium mb-2">Développement</h4>
                      <div className="flex flex-wrap gap-1">
                        <Badge variant="secondary">React</Badge>
                        <Badge variant="secondary">Node.js</Badge>
                        <Badge variant="secondary">TypeScript</Badge>
                        <Badge variant="secondary">Next.js</Badge>
                        <Badge variant="secondary">Python</Badge>
                      </div>
                    </div>
                    <div>
                      <h4 className="font-medium mb-2">Cybersécurité</h4>
                      <div className="flex flex-wrap gap-1">
                        <Badge variant="secondary">Pentesting</Badge>
                        <Badge variant="secondary">OWASP</Badge>
                        <Badge variant="secondary">Cryptographie</Badge>
                        <Badge variant="secondary">Forensic</Badge>
                      </div>
                    </div>
                    <div>
                      <h4 className="font-medium mb-2">Infrastructure</h4>
                      <div className="flex flex-wrap gap-1">
                        <Badge variant="secondary">Docker</Badge>
                        <Badge variant="secondary">Kubernetes</Badge>
                        <Badge variant="secondary">AWS</Badge>
                        <Badge variant="secondary">Linux</Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="lg:col-span-2 space-y-6">
              <Card className="bg-white border border-gray-200">
                <CardHeader>
                  <CardTitle className="text-lg">Expérience Professionnelle</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <h3 className="font-semibold text-foreground">Développeur Full-Stack Senior</h3>
                    <p className="text-primary font-medium">TechCorp • 2022 - Présent</p>
                    <ul className="mt-2 text-sm text-muted-foreground space-y-1">
                      <li>• Développement d'applications React/Node.js pour 50k+ utilisateurs</li>
                      <li>• Mise en place de pratiques DevSecOps et audits de sécurité</li>
                      <li>• Architecture microservices et optimisation des performances</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold text-foreground">Consultant Cybersécurité</h3>
                    <p className="text-primary font-medium">SecureIT • 2020 - 2022</p>
                    <ul className="mt-2 text-sm text-muted-foreground space-y-1">
                      <li>• Tests d'intrusion et audits de sécurité pour PME/ETI</li>
                      <li>• Formation des équipes aux bonnes pratiques de sécurité</li>
                      <li>• Mise en conformité RGPD et certifications ISO 27001</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold text-foreground">Développeur Web</h3>
                    <p className="text-primary font-medium">WebAgency • 2018 - 2020</p>
                    <ul className="mt-2 text-sm text-muted-foreground space-y-1">
                      <li>• Développement de sites e-commerce et applications web</li>
                      <li>• Intégration d'APIs et optimisation SEO</li>
                      <li>• Maintenance et évolution de projets clients</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white border border-gray-200">
                <CardHeader>
                  <CardTitle className="text-lg">Formation</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h3 className="font-semibold text-foreground">Master Cybersécurité</h3>
                    <p className="text-primary font-medium">École Supérieure d'Informatique • 2018</p>
                    <p className="text-sm text-muted-foreground">Spécialisation sécurité des systèmes et réseaux</p>
                  </div>

                  <div>
                    <h3 className="font-semibold text-foreground">Licence Informatique</h3>
                    <p className="text-primary font-medium">Université Paris Diderot • 2016</p>
                    <p className="text-sm text-muted-foreground">Programmation et systèmes d'information</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white border border-gray-200">
                <CardHeader>
                  <CardTitle className="text-lg">Certifications</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Badge variant="outline" className="w-full justify-center py-3 text-center">
                      CISSP - Certified Information Systems Security Professional
                    </Badge>
                    <Badge variant="outline" className="w-full justify-center py-3 text-center">
                      CEH - Certified Ethical Hacker
                    </Badge>
                    <Badge variant="outline" className="w-full justify-center py-3 text-center">
                      AWS Solutions Architect
                    </Badge>
                    <Badge variant="outline" className="w-full justify-center py-3 text-center">
                      OSCP - Offensive Security Certified Professional
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <PortfolioFooter />
    </div>
  )
}
